from django.conf.urls import url
from . import views
from django.views.generic import TemplateView


urlpatterns=[
    url(r'^$', views.frontpageview),
    url(r'^table/$', views.table_1, name="table"),
    url(r'^User/$', views.User_1, name="table"),
    url(r'^board/$', views.dashboard_1, name="table"),
    url(r'^t1/$', TemplateView.as_view(template_name="sidepage.html"),name="svb"),
    url(r'^t2/$', TemplateView.as_view(template_name="table1.html"),name="vb"),
    url(r'^user1/$', TemplateView.as_view(template_name="user.html"),name="svb"),
    url(r'^ceo1/$', TemplateView.as_view(template_name="ceo.html"),name="svb"),
    url(r'^bug/$', TemplateView.as_view(template_name="navigation.html"),name="svb"),
    url(r'^navi/$', TemplateView.as_view(template_name="checkboxtable.html"),name="svb"),
    url(r'^empstatus1/$', TemplateView.as_view(template_name="empstatus.html"),name="svb"),
    url(r'^da1/$', TemplateView.as_view(template_name="d1.html"),name="svb"),
    url(r'^da2/$', TemplateView.as_view(template_name="d5.html"),name="svb"),
    url(r'^da3/$', TemplateView.as_view(template_name="d3.html"),name="svb"),
    url(r'^da4/$', TemplateView.as_view(template_name="d4.html"),name="svb"),
    url(r'^linechart1/$', TemplateView.as_view(template_name="linechart.html"),name="svb"),
    url(r'^bargraph1/$', TemplateView.as_view(template_name="bargraph.html"),name="svb"),

]
