from django.db import models

# Create your models here.
class table2(models.Model):
    name=models.TextField()
    country=models.TextField()
    city=models.TextField()
    salary=models.IntegerField()
