from django.shortcuts import render
from .models import table2

# Create your views here.
def dashboard_1(request):
    return render(request,'dashboard.html')
def User_1(request):
    return render(request,'userprofile.html')
def typo_1(request):
    return render(request,'task4.html')
def frontpageview(request):
            return render(request,'sidepage.html')
def table_1(request):
    return render(request,'tablelist.html')
def tableview(request):
    x=table2.objects.all()
    return render(request,'table1.html',{'all_data':x})
def tableview1(request):
    x=table2.objects.all()
    return render(request,'empstatus.html',{'all_data':x})
